
public abstract class Entity extends NamedThing
{
    public Entity(String n) {
        super(n);
    }
    
    public abstract int computeBattleNumber();
   
}
