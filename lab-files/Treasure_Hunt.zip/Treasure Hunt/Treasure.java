public class Treasure extends Item {
    
    public Treasure (String n, int v) {
        super(n,v);
    }
}
