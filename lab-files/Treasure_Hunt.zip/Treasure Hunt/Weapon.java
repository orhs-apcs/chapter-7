public class Weapon extends Item {
    
    public Weapon (String n, int v) {
        super(n,v);
    }
}
